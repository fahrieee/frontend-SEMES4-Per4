const Footer = () => {
    return (
        <footer>
            <h2>Copyright @aufaroot18</h2>
            <p>Website Ini dibuat menggunakan ReactJS</p>
        </footer>
    );

}
export default Footer;