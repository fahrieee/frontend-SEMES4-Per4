import Hello from "./Hello";

const Main = () => {
    return (
        <main>
        {/*
        Memanggil Component Hello.
        Mengirim props name. 
       */}
            <Hello name="Aufa" />
            <Hello name="Mikel" />
            <Hello name="Hannah" />
            <Hello name="Jonas" />
            <Hello name="martha" />
        </main>
    );
}

export default Main;